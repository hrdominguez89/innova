<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
        Copyright © RIA | 
        <script>
            document.write(new Date().getFullYear())
        </script>
        </div>
    </div>
</footer>