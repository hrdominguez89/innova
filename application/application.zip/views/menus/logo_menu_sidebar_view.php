<div class="logo text-center">
    <div class="photo p-2" style="background-color:white">
      <img class="img-fluid text-primary" src="<?php echo base_url();?>assets/img/logo_ria.svg">
    </div>
  </div>