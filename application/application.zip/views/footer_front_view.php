<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
        Copyright © Innova 4.0 | 
        <script>
            document.write(new Date().getFullYear())
        </script>
        </div>
    </div>
</footer>